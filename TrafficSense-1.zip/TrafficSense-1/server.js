const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const MemoryStore = require('memorystore')(session);
const path = require('path');

const app = express();

// Middlewares
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({
  secret: 'arffic-traffic-management-secret',
  resave: false,
  saveUninitialized: false,
  store: new MemoryStore({
    checkPeriod: 86400000 // 24 hours
  })
}));

// Serve static files from the client/dist folder
app.use(express.static('client/dist'));

// Basic API endpoints for testing
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Server is running' });
});

// Sample locations endpoint
app.get('/api/locations', (req, res) => {
  const locations = [
    {
      id: 1,
      name: "Downtown Main Street",
      latitude: "37.7749",
      longitude: "-122.4194",
      hasTrafficLight: true,
    },
    {
      id: 2,
      name: "Broadway & 5th Avenue",
      latitude: "40.7580",
      longitude: "-73.9855",
      hasTrafficLight: true,
    },
    {
      id: 3,
      name: "Riverside Drive",
      latitude: "34.0522",
      longitude: "-118.2437",
      hasTrafficLight: false,
    }
  ];
  res.json(locations);
});

// Catch all other routes and return the index.html file
app.get('*', (req, res) => {
  res.sendFile(path.resolve(__dirname, 'client/dist', 'index.html'));
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});