export const MAP_CONFIG = {
  DEFAULT_CENTER: { lat: 37.7749, lng: -122.4194 }, // San Francisco coordinates
  DEFAULT_ZOOM: 14,
};

export const TRAFFIC_STATUSES = {
  LIGHT: {
    value: "light",
    label: "Light Traffic",
    color: "#43A047", // Green
    bgColor: "bg-[#43A047]",
    icon: "traffic",
  },
  MEDIUM: {
    value: "medium",
    label: "Medium Traffic",
    color: "#FB8C00", // Orange
    bgColor: "bg-[#FB8C00]",
    icon: "traffic",
  },
  HEAVY: {
    value: "heavy",
    label: "Heavy Traffic",
    color: "#E53935", // Red
    bgColor: "bg-[#E53935]",
    icon: "traffic",
  },
};

export const AREA_TYPES = {
  TRAFFIC_LIGHT: "traffic-light",
  NON_TRAFFIC_LIGHT: "non-traffic-light",
};

export const ROUTES = {
  HOME: "/",
  AUTH: "/auth",
  AREA_SELECTION: "/area-selection",
  LOCATION_SELECTION: "/location-selection",
  LOCATION: "/location",
  TRAFFIC_CLEARED: "/traffic-cleared",
};
