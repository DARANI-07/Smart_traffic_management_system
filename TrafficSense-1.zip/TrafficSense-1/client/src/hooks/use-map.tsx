import { useState, useEffect, useRef, useCallback } from 'react';
import { MAP_CONFIG } from '@/lib/constants';

interface MapOptions {
  center?: google.maps.LatLngLiteral;
  zoom?: number;
}

interface UseMapResult {
  mapRef: React.RefObject<HTMLDivElement>;
  map: google.maps.Map | null;
  isLoaded: boolean;
  error: Error | null;
  setCenter: (center: google.maps.LatLngLiteral) => void;
  setZoom: (zoom: number) => void;
  addMarker: (options: google.maps.MarkerOptions) => google.maps.Marker;
  clearMarkers: () => void;
}

export function useMap(options: MapOptions = {}): UseMapResult {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);

  const center = options.center || MAP_CONFIG.DEFAULT_CENTER;
  const zoom = options.zoom || MAP_CONFIG.DEFAULT_ZOOM;

  // Initialize the map
  useEffect(() => {
    // Check if Google Maps API is loaded
    if (!window.google || !window.google.maps) {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'AIzaSyDb9lKb6Y9bBdDUYYQvPVvYYEWwSb5ZI5g'}&libraries=places`;
      script.async = true;
      script.defer = true;
      script.onerror = () => {
        setError(new Error('Failed to load Google Maps API'));
      };
      script.onload = () => {
        initializeMap();
      };
      document.head.appendChild(script);
    } else {
      initializeMap();
    }

    function initializeMap() {
      if (!mapRef.current) return;

      try {
        const mapInstance = new window.google.maps.Map(mapRef.current, {
          center,
          zoom,
          disableDefaultUI: false,
          zoomControl: true,
          mapTypeControl: false,
          streetViewControl: false,
          fullscreenControl: false,
        });

        setMap(mapInstance);
        setIsLoaded(true);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to initialize map'));
      }
    }

    return () => {
      markersRef.current.forEach(marker => marker.setMap(null));
      markersRef.current = [];
    };
  }, []);

  // Set center method
  const setCenter = useCallback((center: google.maps.LatLngLiteral) => {
    if (map) {
      map.setCenter(center);
    }
  }, [map]);

  // Set zoom method
  const setZoom = useCallback((zoom: number) => {
    if (map) {
      map.setZoom(zoom);
    }
  }, [map]);

  // Add marker method
  const addMarker = useCallback((options: google.maps.MarkerOptions): google.maps.Marker => {
    if (!map) {
      throw new Error('Map not initialized');
    }

    const marker = new google.maps.Marker({
      map,
      ...options,
    });

    markersRef.current.push(marker);
    return marker;
  }, [map]);

  // Clear markers method
  const clearMarkers = useCallback(() => {
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];
  }, []);

  return {
    mapRef,
    map,
    isLoaded,
    error,
    setCenter,
    setZoom,
    addMarker,
    clearMarkers,
  };
}
