import { useLocation } from 'wouter';
import { Header } from '@/components/layout/header';
import { AreaTypeCard } from '@/components/area/area-type-card';
import { ROUTES, AREA_TYPES } from '@/lib/constants';

export default function AreaSelectionPage() {
  const [_, navigate] = useLocation();
  
  const handleTrafficLightArea = () => {
    navigate(`${ROUTES.LOCATION_SELECTION}/${AREA_TYPES.TRAFFIC_LIGHT}`);
  };
  
  const handleNonTrafficLightArea = () => {
    navigate(`${ROUTES.LOCATION_SELECTION}/${AREA_TYPES.NON_TRAFFIC_LIGHT}`);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 p-4 container mx-auto">
        <div className="mb-8">
          <h2 className="text-2xl font-medium mb-6">Select Traffic Area Type</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Traffic Light Area Card */}
            <AreaTypeCard 
              title="Traffic Light Area"
              description="For areas with traffic signals and organized intersections"
              image="https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400"
              badgeText="Recommended"
              badgeColor="bg-blue-100"
              onClick={handleTrafficLightArea}
            />
            
            {/* Non-Traffic Light Area Card */}
            <AreaTypeCard 
              title="Non-Traffic Light Area"
              description="For areas without traffic signals that need police assistance"
              image="https://images.unsplash.com/photo-1600054800747-be294a6a0d26?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400"
              badgeText="Police Notification"
              badgeColor="bg-orange-100"
              onClick={handleNonTrafficLightArea}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
