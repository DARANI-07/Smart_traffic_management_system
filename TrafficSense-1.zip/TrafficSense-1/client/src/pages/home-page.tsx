import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { ROUTES } from '@/lib/constants';

// This is a simple redirect page
export default function HomePage() {
  const [_, navigate] = useLocation();
  
  useEffect(() => {
    // Redirect to area selection page
    navigate(ROUTES.AREA_SELECTION);
  }, [navigate]);
  
  return (
    <div className="min-h-screen flex items-center justify-center">
      <p>Redirecting to Area Selection...</p>
    </div>
  );
}
