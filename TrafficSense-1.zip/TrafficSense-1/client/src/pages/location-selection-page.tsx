import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Location } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, MapPin, Navigation, ChevronRight, ArrowLeftRight } from "lucide-react";
import { Loader2 } from "lucide-react";
import { ROUTES } from "@/lib/constants";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function LocationSelectionPage() {
  const [_, navigate] = useLocation();
  const [match, params] = useRoute("/location-selection/:areaType");
  const areaType = match ? params.areaType : "traffic-light";
  
  const [searchQuery, setSearchQuery] = useState("");
  const [currentLocation, setCurrentLocation] = useState<{lat: number, lng: number} | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const { toast } = useToast();
  
  // Fetch all locations
  const {
    data: locations = [],
    isLoading,
  } = useQuery<Location[]>({
    queryKey: ["/api/locations"],
    queryFn: getQueryFn({ on401: 'throw' }),
  });
  
  // Search location by name
  const searchLocation = useMutation({
    mutationFn: async (query: string) => {
      if (query.length < 2) return null;
      try {
        const res = await apiRequest('GET', `/api/locations/search/${query}`);
        return await res.json();
      } catch (error) {
        return null;
      }
    },
    onSuccess: (data) => {
      if (data) {
        handleLocationSelect(data.id);
      } else {
        toast({
          title: "No location found",
          description: "No matching location found for your search",
          variant: "destructive"
        });
      }
    },
  });
  
  // Filter locations based on search query
  const filteredLocations = locations.filter(location => 
    location.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (areaType === "traffic-light" ? location.hasTrafficLight : !location.hasTrafficLight)
  );
  
  // Handle location search
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };
  
  // Handle search form submit
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.length >= 2) {
      searchLocation.mutate(searchQuery);
    } else {
      toast({
        title: "Search too short",
        description: "Please enter at least 2 characters to search",
      });
    }
  };
  
  // Handle location selection
  const handleLocationSelect = (locationId: number) => {
    navigate(`${ROUTES.LOCATION}/${locationId}`);
  };
  
  // Get current location
  const handleGetCurrentLocation = () => {
    setIsLoadingLocation(true);
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setCurrentLocation({ lat: latitude, lng: longitude });
          
          // Find the closest location to the user's current position
          if (locations.length > 0) {
            const closestLocation = findClosestLocation(latitude, longitude, filteredLocations);
            if (closestLocation) {
              handleLocationSelect(closestLocation.id);
            }
          }
          
          setIsLoadingLocation(false);
        },
        (error) => {
          console.error("Error getting location:", error);
          setIsLoadingLocation(false);
        }
      );
    } else {
      console.error("Geolocation is not supported by this browser.");
      setIsLoadingLocation(false);
    }
  };
  
  // Function to find the closest location to the user's current position
  const findClosestLocation = (lat: number, lng: number, locationList: Location[]) => {
    if (locationList.length === 0) return null;
    
    let closestLocation = locationList[0];
    let closestDistance = calculateDistance(
      lat, 
      lng, 
      parseFloat(locationList[0].latitude), 
      parseFloat(locationList[0].longitude)
    );
    
    for (let i = 1; i < locationList.length; i++) {
      const distance = calculateDistance(
        lat, 
        lng, 
        parseFloat(locationList[i].latitude), 
        parseFloat(locationList[i].longitude)
      );
      
      if (distance < closestDistance) {
        closestDistance = distance;
        closestLocation = locationList[i];
      }
    }
    
    return closestLocation;
  };
  
  // Calculate distance between two coordinates using Haversine formula
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1);
    const dLon = deg2rad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const d = R * c; // Distance in km
    return d;
  };
  
  const deg2rad = (deg: number) => {
    return deg * (Math.PI / 180);
  };
  
  const areaTypeLabel = areaType === "traffic-light" ? "Traffic Light Area" : "No Traffic Light Area";
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header showBackButton title={`Select ${areaTypeLabel}`} />
      
      <main className="flex-1 flex flex-col p-4">
        {/* Current Location Button */}
        <Button
          variant="outline"
          className="w-full mb-4 flex items-center justify-center py-6"
          onClick={handleGetCurrentLocation}
          disabled={isLoadingLocation}
        >
          {isLoadingLocation ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Finding your location...
            </>
          ) : (
            <>
              <Navigation className="mr-2 h-5 w-5" />
              Get Current Location
            </>
          )}
        </Button>
        
        {/* Search Box */}
        <form onSubmit={handleSearchSubmit} className="mb-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <Input
              type="text"
              placeholder="Search location..."
              className="pl-10 pr-20"
              value={searchQuery}
              onChange={handleSearchChange}
            />
            <Button 
              type="submit"
              size="sm"
              className="absolute right-1 top-1/2 transform -translate-y-1/2"
              disabled={searchLocation.isPending}
            >
              {searchLocation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                "Search"
              )}
            </Button>
          </div>
        </form>
        
        {/* Location List */}
        <div className="space-y-3 mb-4">
          <h2 className="text-lg font-medium">
            {areaType === "traffic-light" ? "Traffic Light Areas" : "No Traffic Light Areas"}
          </h2>
          
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredLocations.length === 0 ? (
            <Card>
              <CardContent className="p-6">
                <p className="text-center text-gray-500">
                  No locations found. Try a different search term.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {filteredLocations.map((location) => (
                <Card 
                  key={location.id} 
                  className="cursor-pointer hover:bg-gray-50"
                  onClick={() => handleLocationSelect(location.id)}
                >
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="bg-blue-100 p-2 rounded-full mr-3">
                        <MapPin className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">{location.name}</h3>
                        <p className="text-sm text-gray-500">
                          {location.hasTrafficLight ? "Has traffic light" : "No traffic light"}
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-gray-400" />
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}