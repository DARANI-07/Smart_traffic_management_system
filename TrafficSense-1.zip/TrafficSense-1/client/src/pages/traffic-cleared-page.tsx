import { useEffect, useState } from 'react';
import { useLocation, useSearch } from 'wouter';
import { Header } from '@/components/layout/header';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ROUTES } from '@/lib/constants';
import { MapDisplay } from '@/components/map/map-display';
import { useQuery } from '@tanstack/react-query';
import { getQueryFn } from '@/lib/queryClient';
import { Location } from '@shared/schema';
import { CheckCircle, ChevronLeft } from 'lucide-react';

export default function TrafficClearedPage() {
  const [_, navigate] = useLocation();
  const search = useSearch();
  const locationId = parseInt(new URLSearchParams(search).get('locationId') || '1');
  
  // Get location details
  const { data: locations } = useQuery<Location[]>({
    queryKey: ['/api/locations'],
    queryFn: getQueryFn({ on401: 'throw' }),
  });
  
  const location = locations?.find(l => l.id === locationId);
  
  // Return to area selection
  const handleBackToSelection = () => {
    navigate(ROUTES.AREA_SELECTION);
  };
  
  // Return to location page
  const handleBackToLocation = () => {
    navigate(`${ROUTES.LOCATION}?type=${location?.hasTrafficLight ? 'traffic-light' : 'non-traffic-light'}`);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header showBackButton title="Traffic Cleared" />
      
      <main className="flex-1 flex flex-col">
        {/* Map */}
        <div className="flex-1">
          <MapDisplay
            location={location}
            trafficStatus="light"
          />
        </div>
        
        {/* Status message */}
        <div className="bg-white p-6 z-20">
          <div className="container mx-auto max-w-2xl">
            {/* Success header */}
            <div className="bg-green-500 p-4 text-white text-center rounded-t-md">
              <h2 className="text-xl font-medium">Traffic Cleared Successfully!</h2>
            </div>
            
            {/* Main content */}
            <div className="bg-gray-50 p-6 rounded-b-md border border-gray-200 border-t-0">
              <p className="text-center text-gray-800 mb-2">
                The traffic management system has automatically cleared the traffic.
              </p>
              <p className="text-center text-green-600 font-medium mb-8">
                Vehicles are now moving smoothly through the intersection.
              </p>
              
              {/* Car icon */}
              <div className="flex justify-center mb-8">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-24 text-green-500" fill="currentColor" viewBox="0 0 512 512">
                  <path d="M415.99 144.01H357.9l-36.7-63.43C309.64 61.78 289.9 48 269.94 48h-76.53c-19.96 0-39.7 13.78-51.25 32.58l-36.7 63.43H39.01C17.02 144.01 0 161.15 0 184.01v176c0 17.44 14.78 32.01 31.99 32.01h16c17.99 0 32.01-14.35 32.01-32.01v-16h352v16c0 17.66 14.01 32.01 32.01 32.01h16c17.2 0 31.99-14.57 31.99-32.01v-176c0-22.86-17.02-40-45.01-40zM106.67 80c10.92 0 21.7 7.54 29.33 17.77L165.33 144H89.01l29.33-46.23C126.97 87.54 137.75 80 148.67 80h214.66zM128 288c-17.63 0-32-14.37-32-32s14.37-32 32-32c17.45 0 32 14.36 32 32s-14.55 32-32 32zm304 0H272v-16h-32v16H80c0-44.18-35.82-80-80-80v-96h44.44l30.07-53.89c4.33-7.97 13.75-14.11 21.07-14.11h241.76c7.32 0 16.74 6.14 21.07 14.11L389.41 112H432v96c-44.18 0-80 35.82-80 80zm-16-32c0-17.64 14.55-32 32-32 17.63 0 32 14.37 32 32s-14.37 32-32 32c-17.45 0-32-14.36-32-32z"/>
                </svg>
              </div>
              
              <div className="text-center mb-2">
                <p className="text-gray-700">All sensors are now reporting normal traffic flow.</p>
                <p className="text-gray-700">Time elapsed since traffic cleared: <span className="font-mono">00:03:24</span></p>
              </div>
              
              <div className="flex justify-center mt-6">
                <Button 
                  onClick={handleBackToSelection}
                  className="bg-blue-500 hover:bg-blue-600"
                >
                  Return to Home
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}