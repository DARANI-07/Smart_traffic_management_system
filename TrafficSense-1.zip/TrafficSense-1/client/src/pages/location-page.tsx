import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation, useRoute } from 'wouter';
import { Header } from '@/components/layout/header';
import { MapDisplay } from '@/components/map/map-display';
import { TrafficControls } from '@/components/traffic/traffic-controls';
import { Notification } from '@/components/common/notification';
import { ROUTES } from '@/lib/constants';
import { getQueryFn, queryClient } from '@/lib/queryClient';
import { Location, TrafficReport } from '@shared/schema';
import { Badge } from '@/components/ui/badge';
import { Loader2 } from 'lucide-react';

export default function LocationPage() {
  const [_, navigate] = useLocation();
  const [match, params] = useRoute('/location/:id');
  const locationId = match ? parseInt(params.id) : null;
  
  const [trafficStatus, setTrafficStatus] = useState<string>('light');
  const [showNotification, setShowNotification] = useState(false);
  const [notification, setNotification] = useState({ title: '', message: '' });
  
  // Fetch single location by ID
  const { data: location, isLoading: isLoadingLocation } = useQuery<Location>({
    queryKey: [`/api/locations/${locationId}`],
    queryFn: getQueryFn({ on401: 'throw' }),
    enabled: !!locationId,
  });
  
  // Get traffic status for selected location
  const { data: latestTrafficReport, isLoading: isLoadingTrafficReport } = useQuery<TrafficReport>({
    queryKey: [`/api/traffic-reports/latest/${locationId}`],
    queryFn: getQueryFn({ on401: 'throw' }),
    enabled: !!locationId,
  });
  
  // Effect to update traffic status when report changes
  useEffect(() => {
    if (latestTrafficReport) {
      setTrafficStatus(latestTrafficReport.status);
    }
  }, [latestTrafficReport]);
  
  // Handle traffic status update
  const handleStatusUpdate = (status: string) => {
    setTrafficStatus(status);
  };
  
  // Handle clear traffic
  const handleClearTraffic = () => {
    showStatusNotification('Traffic Clearing', 'Traffic signals have been automated. Traffic should clear in approximately 2 minutes.');
  };
  
  // Handle notify police
  const handleNotifyPolice = () => {
    showStatusNotification('Police Notified', 'Traffic police have been notified and will arrive shortly to manage the situation.');
  };
  
  // Show notification
  const showStatusNotification = (title: string, message: string) => {
    setNotification({ title, message });
    setShowNotification(true);
  };
  
  // Handle dismiss notification
  const handleDismissNotification = () => {
    setShowNotification(false);
  };
  
  // Get status badge color
  const getStatusBadgeClass = () => {
    switch (trafficStatus) {
      case 'light': return 'bg-[#43A047] text-white';
      case 'medium': return 'bg-[#FB8C00] text-white';
      case 'heavy': return 'bg-[#E53935] text-white';
      default: return 'bg-gray-500 text-white';
    }
  };
  
  // Get status label
  const getStatusLabel = () => {
    switch (trafficStatus) {
      case 'light': return 'Light Traffic';
      case 'medium': return 'Medium Traffic';
      case 'heavy': return 'Heavy Traffic';
      default: return 'Unknown Status';
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header showBackButton title="Traffic Light Area" />
      
      <main className="flex-1 flex flex-col">
        {/* Current location */}
        <div className="bg-white px-4 py-2 shadow-md z-10">
          <div className="container mx-auto">
            <h2 className="text-sm font-medium text-gray-500 mb-1">Current Location</h2>
            <div className="flex items-center">
              <div className="flex-shrink-0 mr-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              </div>
              <div className="text-base">
                {location ? location.name : "Loading location..."}
              </div>
            </div>
          </div>
        </div>
        
        {/* Map */}
        <MapDisplay
          location={location || undefined}
          trafficStatus={trafficStatus}
        />
        
        {/* Bottom sheet with traffic controls */}
        <div className="bg-white rounded-t-xl shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] p-4 z-20">
          <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
          <div className="container mx-auto">
            {isLoadingLocation ? (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" />
                <p>Loading location data...</p>
              </div>
            ) : location ? (
              <>
                <h2 className="text-xl font-medium mb-2">{location.name}</h2>
                <div className="flex space-x-2 mb-4">
                  <Badge className={getStatusBadgeClass()}>
                    {getStatusLabel()}
                  </Badge>
                  <Badge variant="outline" className="bg-gray-100 text-gray-600 flex items-center">
                    <svg viewBox="0 0 24 24" className="h-3 w-3 mr-1" fill="currentColor">
                      <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.2 3.2.8-1.3-4.5-2.7z" />
                    </svg>
                    Updated recently
                  </Badge>
                </div>
                
                <TrafficControls
                  locationId={location.id}
                  hasTrafficLight={location.hasTrafficLight}
                  currentStatus={trafficStatus}
                  onStatusUpdate={handleStatusUpdate}
                  onClearTraffic={handleClearTraffic}
                  onNotifyPolice={handleNotifyPolice}
                />
              </>
            ) : (
              <div className="text-center py-4">
                <p>Location not found. Please go back and select a different location.</p>
              </div>
            )}
          </div>
        </div>
        
        {/* Notification overlay */}
        {showNotification && (
          <Notification
            title={notification.title}
            message={notification.message}
            onDismiss={handleDismissNotification}
            autoClose={true}
          />
        )}
      </main>
    </div>
  );
}
