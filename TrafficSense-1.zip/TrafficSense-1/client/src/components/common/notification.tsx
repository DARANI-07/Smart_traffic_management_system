import { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertCircle, X } from "lucide-react";

interface NotificationProps {
  title: string;
  message: string;
  type?: 'success' | 'error' | 'info';
  onDismiss: () => void;
  autoClose?: boolean;
  autoCloseTime?: number;
}

export function Notification({ 
  title, 
  message, 
  type = 'success', 
  onDismiss,
  autoClose = true,
  autoCloseTime = 5000
}: NotificationProps) {
  const [isVisible, setIsVisible] = useState(true);

  // Handle auto-close
  if (autoClose) {
    setTimeout(() => {
      handleDismiss();
    }, autoCloseTime);
  }

  // Handle dismiss
  const handleDismiss = () => {
    setIsVisible(false);
    setTimeout(() => {
      onDismiss();
    }, 300); // Allow animation to complete
  };

  // Icon based on type
  const getIcon = () => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-10 w-10 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-10 w-10 text-red-500" />;
      default:
        return <CheckCircle className="h-10 w-10 text-blue-500" />;
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 animate-in fade-in duration-300">
      <Card className="max-w-md w-full">
        <CardContent className="p-6">
          <div className="flex items-start mb-4">
            <div className="mr-4">
              {getIcon()}
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-medium">{title}</h3>
              <p className="text-gray-600 mt-1">{message}</p>
            </div>
            <button onClick={handleDismiss} className="text-gray-400 hover:text-gray-600">
              <X className="h-5 w-5" />
            </button>
          </div>
          <Button onClick={handleDismiss} className="w-full">
            Got it
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
