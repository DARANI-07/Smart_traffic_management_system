import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronRight } from "lucide-react";

interface AreaTypeCardProps {
  title: string;
  description: string;
  image: string;
  badgeText: string;
  badgeColor: string;
  onClick: () => void;
}

export function AreaTypeCard({
  title,
  description,
  image,
  badgeText,
  badgeColor,
  onClick,
}: AreaTypeCardProps) {
  return (
    <Card 
      className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow duration-300"
      onClick={onClick}
    >
      <div className="h-48 w-full overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
      </div>
      
      <CardHeader className="p-5 pb-0">
        <h3 className="text-xl font-medium">{title}</h3>
      </CardHeader>
      
      <CardContent className="p-5 pt-2">
        <p className="text-gray-600 mb-4">{description}</p>
      </CardContent>
      
      <CardFooter className="p-5 pt-0 flex justify-between items-center">
        <Badge 
          variant="outline" 
          className={`bg-opacity-10 ${badgeColor} text-${badgeColor.replace('bg-', '')}`}
        >
          {badgeText}
        </Badge>
        
        <Button variant="ghost" className="text-primary font-medium flex items-center gap-1 p-0">
          Select <ChevronRight className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}
