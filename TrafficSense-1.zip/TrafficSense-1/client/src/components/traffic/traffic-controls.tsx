import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { TRAFFIC_STATUSES, ROUTES } from '@/lib/constants';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';

interface TrafficControlsProps {
  locationId: number;
  hasTrafficLight: boolean;
  currentStatus?: string;
  onStatusUpdate?: (status: string) => void;
  onClearTraffic?: () => void;
  onNotifyPolice?: () => void;
}

export function TrafficControls({ 
  locationId, 
  hasTrafficLight, 
  currentStatus = 'light',
  onStatusUpdate,
  onClearTraffic,
  onNotifyPolice
}: TrafficControlsProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedStatus, setSelectedStatus] = useState(currentStatus);

  // Mutation for updating traffic status
  const updateTrafficMutation = useMutation({
    mutationFn: async (status: string) => {
      const res = await apiRequest('POST', '/api/traffic-reports', {
        locationId,
        status,
        userId: user?.id,
      });
      
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [`/api/traffic-reports/latest/${locationId}`] });
      if (onStatusUpdate) {
        onStatusUpdate(data.status);
      }
      
      const statusKey = data.status.toUpperCase() as keyof typeof TRAFFIC_STATUSES;
      toast({
        title: "Traffic Updated",
        description: `Traffic status has been updated to ${TRAFFIC_STATUSES[statusKey].label}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update traffic status",
        variant: "destructive",
      });
    }
  });

  // Mutation for clearing traffic
  const clearTrafficMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/traffic-reports', {
        locationId,
        status: 'light',
        userId: user?.id,
        description: 'Traffic cleared automatically',
      });
      
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/traffic-reports/latest/${locationId}`] });
      if (onClearTraffic) {
        onClearTraffic();
      }
      
      toast({
        title: "Traffic Clearing",
        description: "Traffic signals have been automated. Traffic should clear in approximately 2 minutes.",
      });
      
      // Update status to light after 2 seconds
      setTimeout(() => {
        if (onStatusUpdate) {
          onStatusUpdate('light');
        }
      }, 2000);
    },
    onError: (error) => {
      toast({
        title: "Failed to Clear Traffic",
        description: error.message || "Failed to clear traffic",
        variant: "destructive",
      });
    }
  });

  // Mutation for notifying police
  const notifyPoliceMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/police-notifications', {
        locationId,
        userId: user?.id,
        description: 'Traffic congestion requires police assistance',
      });
      
      return await res.json();
    },
    onSuccess: () => {
      if (onNotifyPolice) {
        onNotifyPolice();
      }
      
      toast({
        title: "Police Notified",
        description: "Traffic police have been notified and will arrive shortly to manage the situation.",
      });
    },
    onError: (error) => {
      toast({
        title: "Notification Failed",
        description: error.message || "Failed to notify police",
        variant: "destructive",
      });
    }
  });

  // Handle traffic status update
  const handleUpdateTraffic = (status: string) => {
    setSelectedStatus(status);
    updateTrafficMutation.mutate(status);
  };

  // Handle clear traffic button click
  const [_, navigate] = useLocation();
  
  const handleClearTraffic = () => {
    clearTrafficMutation.mutate();
    
    // Navigate to traffic cleared page after a short delay
    setTimeout(() => {
      navigate(`${ROUTES.TRAFFIC_CLEARED}?locationId=${locationId}`);
    }, 1000);
  };

  // Handle notify police button click
  const handleNotifyPolice = () => {
    notifyPoliceMutation.mutate();
    
    // Navigate to traffic cleared page after a short delay
    setTimeout(() => {
      navigate(`${ROUTES.TRAFFIC_CLEARED}?locationId=${locationId}`);
    }, 1000);
  };

  if (hasTrafficLight) {
    return (
      <div>
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-4">Traffic Status</h3>
          <div className="flex justify-between mb-4">
            {Object.values(TRAFFIC_STATUSES).map((status) => (
              <div key={status.value} className="flex items-center">
                <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: status.color }}></div>
                <span>{status.label}</span>
              </div>
            ))}
          </div>
          
          <h4 className="text-sm text-gray-600 mb-2">Update traffic intensity:</h4>
          <div className="mb-4">
            <div className="flex justify-between text-xs mb-1">
              <span>Light</span>
              <span>Medium</span>
              <span>Heavy</span>
            </div>
            <div className="grid grid-cols-3 gap-0">
              <button 
                onClick={() => handleUpdateTraffic('light')}
                className={`py-2 ${selectedStatus === 'light' ? 'bg-green-500 text-white' : 'bg-gray-100'} hover:bg-green-500 hover:text-white transition-colors`}
              >
                Light
              </button>
              <button 
                onClick={() => handleUpdateTraffic('medium')}
                className={`py-2 ${selectedStatus === 'medium' ? 'bg-yellow-500 text-white' : 'bg-gray-100'} hover:bg-yellow-500 hover:text-white transition-colors`}
              >
                Medium
              </button>
              <button 
                onClick={() => handleUpdateTraffic('heavy')}
                className={`py-2 ${selectedStatus === 'heavy' ? 'bg-red-500 text-white' : 'bg-gray-100'} hover:bg-red-500 hover:text-white transition-colors`}
              >
                Heavy
              </button>
            </div>
          </div>
          
          <Button 
            className="w-full bg-blue-500 hover:bg-blue-600 text-white"
            onClick={() => handleUpdateTraffic(selectedStatus)}
            disabled={updateTrafficMutation.isPending}
          >
            {updateTrafficMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Updating Traffic Status...
              </>
            ) : (
              'Update Traffic Status'
            )}
          </Button>
        </div>
        
        <div className="flex items-center mb-4">
          <div className="flex-1">
            <svg className="inline-block h-5 w-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span className="text-sm">Estimated travel time: 25-30 min</span>
          </div>
          <Button 
            className="bg-orange-500 hover:bg-orange-600 text-white"
            onClick={handleClearTraffic}
            disabled={clearTrafficMutation.isPending}
          >
            {clearTrafficMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Clearing...
              </>
            ) : (
              'Clear Traffic'
            )}
          </Button>
        </div>
        
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-4">Traffic History</h3>
          <table className="w-full text-sm">
            <thead className="text-left text-gray-600 uppercase text-xs">
              <tr>
                <th className="py-2 pr-4">Time</th>
                <th className="py-2 pr-4">Status</th>
                <th className="py-2">Description</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="py-4" colSpan={3}>
                  <p className="text-center text-gray-500">No traffic history available</p>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  }
  
  return (
    <div>
      <h3 className="text-lg font-medium mb-3">Report Traffic Issue</h3>
      <Button 
        className="w-full bg-[#F57C00] hover:bg-[#EF6C00] mb-4"
        onClick={handleNotifyPolice}
        disabled={notifyPoliceMutation.isPending}
      >
        {notifyPoliceMutation.isPending ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Notifying Police...
          </>
        ) : (
          <>
            <svg viewBox="0 0 24 24" className="h-5 w-5 mr-2" fill="currentColor">
              <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z" />
            </svg>
            Notify Traffic Police
          </>
        )}
      </Button>
      
      <Card className="bg-gray-50 border-gray-200">
        <CardContent className="p-3">
          <p className="text-sm text-gray-600">
            Traffic police will be notified about the congestion in this area. You'll receive a notification once they're on their way.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
