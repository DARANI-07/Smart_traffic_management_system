import { Card, CardContent } from '@/components/ui/card';
import { TRAFFIC_STATUSES } from '@/lib/constants';

export function TrafficLegend() {
  return (
    <Card className="bg-white shadow-lg">
      <CardContent className="p-4">
        <h3 className="text-sm font-medium mb-2">Traffic Legend</h3>
        <div className="space-y-2">
          {Object.values(TRAFFIC_STATUSES).map((status) => (
            <div key={status.value} className="flex items-center">
              <span 
                className={`w-4 h-4 rounded-full mr-2`}
                style={{ backgroundColor: status.color }}
              />
              <span className="text-sm">{status.label}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
