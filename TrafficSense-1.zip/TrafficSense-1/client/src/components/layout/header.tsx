import { useState } from 'react';
import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { ROUTES } from "@/lib/constants";
import { ChevronLeft, User, LogOut } from "lucide-react";

interface HeaderProps {
  showBackButton?: boolean;
  title?: string;
}

export function Header({ showBackButton = false, title = "Traffic Light Area" }: HeaderProps) {
  const [_, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleBack = () => {
    navigate(ROUTES.AREA_SELECTION);
  };

  return (
    <header className="bg-white shadow-md p-4">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center">
          {showBackButton && (
            <Button 
              onClick={handleBack} 
              variant="ghost" 
              size="icon" 
              className="mr-2"
              aria-label="Go back"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
          )}
          <Link href={ROUTES.HOME}>
            <h1 className="text-2xl font-medium text-primary cursor-pointer">
              {title}
            </h1>
          </Link>
        </div>
        
        <div className="flex items-center space-x-4">
          {user && (
            <>
              <span className="hidden md:inline text-sm">
                {user.name}
              </span>
              <DropdownMenu open={dropdownOpen} onOpenChange={setDropdownOpen}>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="rounded-full h-10 w-10"
                    aria-label="User menu"
                  >
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
