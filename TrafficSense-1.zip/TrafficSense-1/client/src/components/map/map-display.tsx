import { useEffect, useState } from 'react';
import { useMap } from '@/hooks/use-map';
import { TRAFFIC_STATUSES } from '@/lib/constants';
import { TrafficLegend } from '@/components/traffic/traffic-legend';
import { Location } from '@shared/schema';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertCircle } from 'lucide-react';

interface MapDisplayProps {
  location?: Location;
  trafficStatus?: string;
}

export function MapDisplay({ location, trafficStatus = 'light' }: MapDisplayProps) {
  const { mapRef, isLoaded, error, map, addMarker } = useMap();
  const [mapInitialized, setMapInitialized] = useState(false);

  // Initialize map and add markers when location changes
  useEffect(() => {
    if (isLoaded && map && location && !mapInitialized) {
      const position = {
        lat: parseFloat(location.latitude),
        lng: parseFloat(location.longitude),
      };

      // Set center of map to location
      map.setCenter(position);

      // Add marker at location
      const marker = addMarker({
        position,
        title: location.name,
      });

      // Add info window to marker
      const infoWindow = new google.maps.InfoWindow({
        content: `<div class="p-2">
                    <h3 class="font-medium">${location.name}</h3>
                    <p>${location.hasTrafficLight ? 'Has traffic lights' : 'No traffic lights'}</p>
                  </div>`,
      });

      marker.addListener('click', () => {
        infoWindow.open(map, marker);
      });

      setMapInitialized(true);
    }
  }, [isLoaded, map, location, addMarker, mapInitialized]);

  // Show loading skeleton when map is not loaded
  if (!isLoaded) {
    return (
      <div className="flex-1 relative">
        <Skeleton className="w-full h-full" />
      </div>
    );
  }

  // Show error message if map failed to load
  if (error) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-100">
        <div className="text-center p-6">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-2" />
          <h3 className="text-lg font-medium">Failed to load map</h3>
          <p className="text-gray-600 mt-1">Please check your internet connection and try again</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 relative">
      <div ref={mapRef} className="w-full h-full" />
      
      {/* Traffic legend overlay */}
      <div className="absolute bottom-4 right-4">
        <TrafficLegend />
      </div>
    </div>
  );
}
