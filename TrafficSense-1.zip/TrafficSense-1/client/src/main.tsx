import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add meta tags for SEO
document.title = "Arffic - Traffic Management System";

// Create meta description
const metaDescription = document.createElement("meta");
metaDescription.name = "description";
metaDescription.content = "Monitor and report traffic conditions in real-time with Arffic Traffic Management System. Get updates on traffic status and receive notifications.";
document.head.appendChild(metaDescription);

// Open Graph tags
const ogTitle = document.createElement("meta");
ogTitle.property = "og:title";
ogTitle.content = "Arffic - Traffic Management System";
document.head.appendChild(ogTitle);

const ogDescription = document.createElement("meta");
ogDescription.property = "og:description";
ogDescription.content = "Real-time traffic monitoring and reporting system with user notifications and police alerts.";
document.head.appendChild(ogDescription);

const ogType = document.createElement("meta");
ogType.property = "og:type";
ogType.content = "website";
document.head.appendChild(ogType);

// Render the app
createRoot(document.getElementById("root")!).render(<App />);
