import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

// Pages
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import AreaSelectionPage from "@/pages/area-selection-page";
import LocationSelectionPage from "@/pages/location-selection-page";
import LocationPage from "@/pages/location-page";
import TrafficClearedPage from "@/pages/traffic-cleared-page";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={HomePage} />
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/area-selection" component={AreaSelectionPage} />
      <ProtectedRoute path="/location-selection/:areaType" component={LocationSelectionPage} />
      <ProtectedRoute path="/location/:id" component={LocationPage} />
      <ProtectedRoute path="/traffic-cleared" component={TrafficClearedPage} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
