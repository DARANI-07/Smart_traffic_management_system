import { pgTable, text, serial, integer, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  name: true,
  phone: true,
});

// Traffic Status Enum
export const trafficStatusEnum = pgEnum('traffic_status', ['light', 'medium', 'heavy']);

// Location model
export const locations = pgTable("locations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  hasTrafficLight: boolean("has_traffic_light").notNull(),
});

export const insertLocationSchema = createInsertSchema(locations).pick({
  name: true,
  latitude: true,
  longitude: true,
  hasTrafficLight: true,
});

// Traffic Report model
export const trafficReports = pgTable("traffic_reports", {
  id: serial("id").primaryKey(),
  locationId: integer("location_id").notNull(),
  userId: integer("user_id").notNull(),
  status: trafficStatusEnum("status").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  description: text("description"),
});

export const insertTrafficReportSchema = createInsertSchema(trafficReports).pick({
  locationId: true,
  userId: true,
  status: true,
  description: true,
});

// Police Notification model
export const policeNotifications = pgTable("police_notifications", {
  id: serial("id").primaryKey(),
  locationId: integer("location_id").notNull(),
  userId: integer("user_id").notNull(),
  status: text("status").notNull().default("pending"), // pending, dispatched, resolved
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  description: text("description"),
});

export const insertPoliceNotificationSchema = createInsertSchema(policeNotifications).pick({
  locationId: true,
  userId: true,
  description: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertLocation = z.infer<typeof insertLocationSchema>;
export type Location = typeof locations.$inferSelect;

export type InsertTrafficReport = z.infer<typeof insertTrafficReportSchema>;
export type TrafficReport = typeof trafficReports.$inferSelect;

export type InsertPoliceNotification = z.infer<typeof insertPoliceNotificationSchema>;
export type PoliceNotification = typeof policeNotifications.$inferSelect;

// Extended schemas with validation
export const extendedUserSchema = insertUserSchema.extend({
  // Username should be at least 4 characters
  username: z.string().min(4, "Username must be at least 4 characters"),
  // Email should be a valid email
  email: z.string().email("Please enter a valid email address"),
  // Password should be at least 6 characters
  password: z.string().min(6, "Password must be at least 6 characters"),
  // Phone number validation (basic pattern)
  phone: z.string().regex(/^\+?[0-9]{10,15}$/, "Please enter a valid phone number"),
  // Name should not be empty
  name: z.string().min(1, "Name is required"),
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export type LoginData = z.infer<typeof loginSchema>;
