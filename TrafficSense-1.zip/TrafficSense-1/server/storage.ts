import { 
  users, type User, type InsertUser,
  locations, type Location, type InsertLocation,
  trafficReports, type TrafficReport, type InsertTrafficReport,
  policeNotifications, type PoliceNotification, type InsertPoliceNotification
} from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { eq, desc, sql } from "drizzle-orm";
import { db, pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Location operations
  getLocation(id: number): Promise<Location | undefined>;
  getLocationByName(name: string): Promise<Location | undefined>;
  getLocations(): Promise<Location[]>;
  createLocation(location: InsertLocation): Promise<Location>;
  
  // Traffic Report operations
  getTrafficReport(id: number): Promise<TrafficReport | undefined>;
  getTrafficReportsByLocation(locationId: number): Promise<TrafficReport[]>;
  getLatestTrafficReportByLocation(locationId: number): Promise<TrafficReport | undefined>;
  createTrafficReport(report: InsertTrafficReport): Promise<TrafficReport>;
  
  // Police Notification operations
  getPoliceNotification(id: number): Promise<PoliceNotification | undefined>;
  getPoliceNotificationsByLocation(locationId: number): Promise<PoliceNotification[]>;
  createPoliceNotification(notification: InsertPoliceNotification): Promise<PoliceNotification>;
  updatePoliceNotificationStatus(id: number, status: string): Promise<PoliceNotification | undefined>;
  
  // Session store
  sessionStore: any;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    // Initialize session store with PostgreSQL
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true 
    });
    
    // Initialize database with default locations if needed
    this.initializeDatabase();
  }

  private async initializeDatabase() {
    // Check if there are any locations, if not, add some default ones
    const existingLocations = await db.select().from(locations);
    
    if (existingLocations.length === 0) {
      // Add some initial location data
      await this.createLocation({
        name: "Downtown Main Street",
        latitude: "37.7749",
        longitude: "-122.4194",
        hasTrafficLight: true,
      });
      
      await this.createLocation({
        name: "Broadway & 5th Avenue",
        latitude: "40.7580",
        longitude: "-73.9855",
        hasTrafficLight: true,
      });
      
      await this.createLocation({
        name: "Riverside Drive",
        latitude: "34.0522",
        longitude: "-118.2437",
        hasTrafficLight: false,
      });
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Location methods
  async getLocation(id: number): Promise<Location | undefined> {
    const [location] = await db.select().from(locations).where(eq(locations.id, id));
    return location;
  }
  
  async getLocationByName(name: string): Promise<Location | undefined> {
    // Use basic comparison instead of complex SQL for compatibility
    const allLocations = await db.select().from(locations);
    const matchedLocation = allLocations.find(loc => 
      loc.name.toLowerCase().includes(name.toLowerCase())
    );
    return matchedLocation;
  }
  
  async getLocations(): Promise<Location[]> {
    return await db.select().from(locations);
  }
  
  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const [location] = await db.insert(locations).values(insertLocation).returning();
    return location;
  }
  
  // Traffic Report methods
  async getTrafficReport(id: number): Promise<TrafficReport | undefined> {
    const [report] = await db.select().from(trafficReports).where(eq(trafficReports.id, id));
    return report;
  }
  
  async getTrafficReportsByLocation(locationId: number): Promise<TrafficReport[]> {
    return await db
      .select()
      .from(trafficReports)
      .where(eq(trafficReports.locationId, locationId))
      .orderBy(desc(trafficReports.timestamp));
  }
  
  async getLatestTrafficReportByLocation(locationId: number): Promise<TrafficReport | undefined> {
    const [report] = await db
      .select()
      .from(trafficReports)
      .where(eq(trafficReports.locationId, locationId))
      .orderBy(desc(trafficReports.timestamp))
      .limit(1);
    
    return report;
  }
  
  async createTrafficReport(insertReport: InsertTrafficReport): Promise<TrafficReport> {
    const reportWithTimestamp: InsertTrafficReport & { timestamp: Date } = {
      ...insertReport,
      description: insertReport.description || null, // Ensure description is not undefined
      timestamp: new Date()
    };
    
    const [report] = await db
      .insert(trafficReports)
      .values(reportWithTimestamp)
      .returning();
      
    return report;
  }
  
  // Police Notification methods
  async getPoliceNotification(id: number): Promise<PoliceNotification | undefined> {
    const [notification] = await db
      .select()
      .from(policeNotifications)
      .where(eq(policeNotifications.id, id));
      
    return notification;
  }
  
  async getPoliceNotificationsByLocation(locationId: number): Promise<PoliceNotification[]> {
    return await db
      .select()
      .from(policeNotifications)
      .where(eq(policeNotifications.locationId, locationId))
      .orderBy(desc(policeNotifications.timestamp));
  }
  
  async createPoliceNotification(insertNotification: InsertPoliceNotification): Promise<PoliceNotification> {
    const notificationWithDefaults = {
      ...insertNotification,
      description: insertNotification.description || null, // Ensure description is not undefined
      status: "pending",
      timestamp: new Date()
    };
    
    const [notification] = await db
      .insert(policeNotifications)
      .values(notificationWithDefaults)
      .returning();
    
    // Auto update to dispatched after 5 seconds
    setTimeout(async () => {
      await this.updatePoliceNotificationStatus(notification.id, "dispatched");
    }, 5000);
    
    return notification;
  }
  
  async updatePoliceNotificationStatus(id: number, status: string): Promise<PoliceNotification | undefined> {
    const [updatedNotification] = await db
      .update(policeNotifications)
      .set({ status })
      .where(eq(policeNotifications.id, id))
      .returning();
    
    return updatedNotification;
  }
}

// Switch to DatabaseStorage for persistent storage
export const storage = new DatabaseStorage();
