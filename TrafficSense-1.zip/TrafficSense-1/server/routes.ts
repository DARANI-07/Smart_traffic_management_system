import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertTrafficReportSchema, insertPoliceNotificationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);
  
  // Get all locations
  app.get("/api/locations", async (req, res) => {
    try {
      const locations = await storage.getLocations();
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch locations" });
    }
  });
  
  // Get location by ID
  app.get("/api/locations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const location = await storage.getLocation(id);
      
      if (!location) {
        return res.status(404).json({ message: "Location not found" });
      }
      
      res.json(location);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch location" });
    }
  });
  
  // Search locations by name
  app.get("/api/locations/search/:query", async (req, res) => {
    try {
      const query = req.params.query;
      if (!query || query.length < 2) {
        return res.status(400).json({ message: "Search query too short" });
      }
      
      const location = await storage.getLocationByName(query);
      if (!location) {
        return res.status(404).json({ message: "No matching locations found" });
      }
      
      res.json(location);
    } catch (error) {
      res.status(500).json({ message: "Failed to search locations" });
    }
  });

  // Get latest traffic report for a location
  app.get("/api/traffic-reports/latest/:locationId", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const locationId = parseInt(req.params.locationId);
      const report = await storage.getLatestTrafficReportByLocation(locationId);
      
      if (!report) {
        return res.status(404).json({ message: "No traffic reports found for this location" });
      }
      
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch traffic report" });
    }
  });
  
  // Create a new traffic report
  app.post("/api/traffic-reports", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const result = insertTrafficReportSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid traffic report data" });
      }
      
      const { data } = result;
      const report = await storage.createTrafficReport({
        ...data,
        userId: req.user!.id,
      });
      
      res.status(201).json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to create traffic report" });
    }
  });
  
  // Create a new police notification
  app.post("/api/police-notifications", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const result = insertPoliceNotificationSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid police notification data" });
      }
      
      const { data } = result;
      const notification = await storage.createPoliceNotification({
        ...data,
        userId: req.user!.id,
      });
      
      res.status(201).json(notification);
    } catch (error) {
      res.status(500).json({ message: "Failed to create police notification" });
    }
  });
  
  // Get police notification status
  app.get("/api/police-notifications/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const id = parseInt(req.params.id);
      const notification = await storage.getPoliceNotification(id);
      
      if (!notification) {
        return res.status(404).json({ message: "Police notification not found" });
      }
      
      res.json(notification);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch police notification" });
    }
  });
  
  // Get police notifications for a location
  app.get("/api/police-notifications/location/:locationId", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const locationId = parseInt(req.params.locationId);
      const notifications = await storage.getPoliceNotificationsByLocation(locationId);
      
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch police notifications" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
